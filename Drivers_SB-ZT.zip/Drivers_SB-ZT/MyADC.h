#ifndef MYADC_H
#define MYADC_H
#include "stm32f10x.h"

void myADC_Init(ADC_TypeDef * ADC, uint16_t psc, char channel);






#endif
